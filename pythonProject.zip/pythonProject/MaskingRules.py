import os

import pandas as pd
from NameMasker import *

fake_names = []
with open(os.path.join('dictionary', 'distinct_names.txt'), 'r') as file:
    for line in file:
        fake_names.append(line.strip())
fake_phone = []
with open(os.path.join('dictionary', 'distinct_phone.txt'), 'r') as file:
    for line in file:
        fake_phone.append(line.strip())

fake_ssn = []
with open(os.path.join('dictionary', 'distinct_ssn.txt'), 'r') as file:
    for line in file:
        fake_ssn.append(line.strip())
fake_email = []
with open(os.path.join('dictionary', 'distinct_email.txt'), 'r') as file:
    for line in file:
        fake_email.append(line.strip())


class MaskingRules:
    @staticmethod
    def mask_phone_column(df, column_name):
        masker = NameMasker("key3", fake_phone)
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(masker.mask_name)
        else:
            print(f"Column '{column_name}' not found in DataFrame.")

    @staticmethod
    def mask_name_column(df, column_name):
        masker = NameMasker("key3", fake_names)
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(masker.mask_name)
        else:
            print(f"Column '{column_name}' not found in DataFrame.")

    @staticmethod
    def mask_ssn_column(df, column_name):
        masker = NameMasker("key3", fake_ssn)
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(masker.mask_name)
        else:
            print(f"Column '{column_name}' not found in DataFrame.")

    @staticmethod
    def mask_email_column(df, column_name):
        masker = NameMasker("key3", fake_email)
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(masker.mask_name)
        else:
            print(f"Column '{column_name}' not found in DataFrame.")

