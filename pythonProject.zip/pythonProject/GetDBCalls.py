import mysql.connector
import base64


class GetDBCalls:
    def get_tables_and_columns(conn_string_base64):
        try:
            # Decode the base64-encoded connection string
            conn_string = base64.b64decode(conn_string_base64).decode("utf-8")

            # Establish a connection to the MySQL database
            conn = mysql.connector.connect(**eval(conn_string))  # Convert the string to a dictionary

            # Create a cursor to execute SQL queries
            cursor = conn.cursor()

            # Get the list of tables in the database
            cursor.execute("SHOW TABLES")
            tables = [table[0] for table in cursor.fetchall()]

            # Retrieve column names for each table
            table_columns = {}
            for table in tables:
                cursor.execute(f"DESCRIBE {table}")
                columns = [column[0] for column in cursor.fetchall()]
                table_columns[table] = columns

            # Close the cursor and connection
            cursor.close()
            conn.close()

            return table_columns

        except Exception as e:
            return {"error": str(e)}
