
import hashlib


class NameMasker:
    def __init__(self, key, real_names):
        self.key = key
        self.real_names = real_names
        self.mapping = {}

    def mask_name(self, real_name):
        # Check if the real name has already been mapped
        if real_name in self.mapping:
            return self.mapping[real_name]

        # Generate a hash of the real name and key
        hashed_name = hashlib.sha256((real_name + self.key).encode()).hexdigest()

        # Use the first few characters of the hash as an index to select a realistic pseudonym
        pseudonym = self.real_names[int(hashed_name[:8], 16) % len(self.real_names)]

        # Store the mapping for future consistency
        self.mapping[real_name] = pseudonym

        return pseudonym
