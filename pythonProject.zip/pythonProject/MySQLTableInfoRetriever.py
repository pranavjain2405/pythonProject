import mysql.connector
from flask import jsonify


class MySQLTableInfoRetriever:
    def __init__(self, conn_json):
        self.conn_json = conn_json

    def get_tables_and_columns(self):

        try:
            # Establish a connection to the MySQL database using the connection details from conn_json
            conn = mysql.connector.connect(
                host=self.conn_json['server'],
                user=self.conn_json['uid'],
                password=self.conn_json['pwd'],
                database=self.conn_json['database']
            )
            # Create a cursor to execute SQL queries
            cursor = conn.cursor()

            # Get the list of tables in the database
            cursor.execute("SHOW TABLES")
            tables = [table[0] for table in cursor.fetchall()]

            # Retrieve column names for each table
            table_columns = {}
            for table in tables:
                cursor.execute(f"DESCRIBE {table}")
                columns = cursor.fetchall()  # Fetch all column information
                for col in columns:
                    print(col[0],col[1].decode())

                column_info = [{"Column": col[0], "Type": col[1].decode()} for col in columns]

                table_columns[table] = column_info

            # Close the cursor and connection
            print(table_columns)
            cursor.close()
            conn.close()

            return table_columns

        except mysql.connector.Error as err:
            return {"error": str(err)}
