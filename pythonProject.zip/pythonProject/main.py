import base64

from flask import Flask, request, jsonify
import re
import json
from json_processor import *
from MySQLTableInfoRetriever import *
from flask_cors import CORS

app = Flask(__name__)
cors = CORS(app, resources={r"/get_tables_and_columns": {"origins": "http://localhost:4200"}, r"/process_json": {"origins": "http://localhost:4200"}})


@app.route('/process_json', methods=['POST'])
def process_json():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid JSON data"}), 400

        json_processor = JsonProcessor()
        json_processor.process_json(data)
        response_data = {"result": "Data Masked and Written to Target"}
        return jsonify(response_data), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/get_tables_and_columns', methods=['GET'])
def api_get_tables_and_columns():
    try:
        conn_string_base64 = request.args.get('con')
        json_processor = JsonProcessor()
        conn_dict = json_processor.decode_and_parse_conn_string(conn_string_base64)
        print('2', conn_dict)
        # Convert the dictionary to JSON format
        conn_json = json.dumps(conn_dict, indent=4)

        print(conn_json)
        if not conn_string_base64:
            return jsonify({"error": "Missing 'con' parameter"}), 400

            # Create an instance of MySQLTableInfoRetriever
        table_info_retriever = MySQLTableInfoRetriever(conn_dict)

        # Retrieve tables and their column names
        tables_and_columns = table_info_retriever.get_tables_and_columns()
        json_string = json.dumps(tables_and_columns)

        if "error" in tables_and_columns:
            print(f"Error: {tables_and_columns['error']}")
        else:
            return json_string, 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
