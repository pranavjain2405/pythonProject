import base64
import re
from flask import Flask, request, jsonify
from SqlOpr import *
from MaskingRules import *


class JsonProcessor:
    @staticmethod
    def process_json(data):
        # Your processing logic here
        # Example: Print the JSON
        print(data)

        source_conn = data.get('sourceConn', '')
        conn_dict_src = JsonProcessor.decode_and_parse_conn_string(source_conn)
        target_conn = data.get('targetConn', '')
        conn_dict_tgt = JsonProcessor.decode_and_parse_conn_string(target_conn)

        mapped_template = {}
        for item in data.get('mappedTemplate', []):
            for table_name, column_mapping in item.items():
                mapped_template[table_name] = column_mapping
        print(mapped_template)
        user_email = data.get('userEmail', '')
        user_id = data.get('userId', '')

        table_names = list(mapped_template.keys())
        print(table_names)
        masking_rules = MaskingRules()
        # Iterate over the table names
        for table_name in table_names:

            # Get the column mapping for the current table
            column_mapping = mapped_template[table_name]
            print(column_mapping)
            sql_opr = SqlOpr(conn_dict_src, conn_dict_tgt)
            df = sql_opr.read(table_name)
            # Iterate over the column mapping for the current table
            for column_name, masking_type in column_mapping.items():
                print(column_name, masking_type)
                if masking_type == 'Name Masking':
                    masking_rules.mask_name_column(df, column_name)
                elif masking_type == 'SSN Masking':
                    masking_rules.mask_ssn_column(df, column_name)
                elif masking_type == 'Email Masking':
                    masking_rules.mask_email_column(df, column_name)
                elif masking_type == 'Phone Masking':
                    masking_rules.mask_phone_column(df, column_name)


            if df is not None:
                print(df.head())  # Print the first few rows of the DataFrame
                sql_opr.write(table_name, df)

    @staticmethod
    def decode_and_parse_conn_string(conn_string_base64):
        try:
            # Decode the base64-encoded connection string to UTF-8
            print('1',conn_string_base64)
            conn_string = base64.b64decode(conn_string_base64).decode("utf-8")

            # Split the connection string into key-value pairs using regular expressions
            pattern = r'(\w+)=(\w+)'
            matches = re.findall(pattern, conn_string)

            # Convert the matches into a dictionary
            conn_dict = {key: value for key, value in matches}

            return conn_dict

        except Exception as e:
            print(f"Error decoding and parsing connection string: {str(e)}")
            return None  # Return None on error
