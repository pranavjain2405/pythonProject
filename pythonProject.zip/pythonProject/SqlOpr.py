import pandas as pd
import mysql.connector
from sqlalchemy import create_engine


class SqlOpr:
    def __init__(self, source_conn_str,target_conn_str):
        self.source_conn_str = source_conn_str
        self.target_conn_str = target_conn_str

    def read(self, table_name):
        try:
            # Establish a connection to the MySQL database
            conn = mysql.connector.connect(
                host=self.source_conn_str['server'],
                user=self.source_conn_str['uid'],
                password=self.source_conn_str['pwd'],
                database=self.source_conn_str['database']
            )

            # Create a DataFrame by querying the MySQL table
            query = f"SELECT * FROM {table_name}"
            df = pd.read_sql(query, conn)

            # Close the database connection
            conn.close()

            return df
        except Exception as e:
            print(f"Error: {str(e)}")
            return None

    def write(self, table_name, df):
        db_params = self.target_conn_str
        print(db_params)
        try:
            # Establish a connection to the target MySQL database

            target_conn = mysql.connector.connect(
                host=self.target_conn_str['server'],
                user=self.target_conn_str['uid'],
                password=self.target_conn_str['pwd'],
                database=self.target_conn_str['database']
            )
            print('write con2')
            engine = create_engine(
                f"mysql+mysqlconnector://{db_params['uid']}:{db_params['pwd']}@{db_params['server']}/{db_params['database']}")
            print('write con3')
            df.to_sql(name=table_name, con=engine, if_exists='replace', index=False)
            # Close the target database connection
            target_conn.close()

            print(f"Data written to {table_name} in target database.")
        except Exception as e:
            print(f"Error: {str(e)}")
